/**
 * @prettier
 */
const int64Generator = () => 0

export default int64Generator
